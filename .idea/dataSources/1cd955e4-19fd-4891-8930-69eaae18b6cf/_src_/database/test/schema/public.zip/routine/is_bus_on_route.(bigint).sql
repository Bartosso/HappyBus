create function is_bus_on_route(busid bigint) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
BEGIN
  IF (SELECT buses.ready_to_home FROM buses WHERE buses.id=busId) = TRUE
     OR (SELECT buses.ready_to_school FROM buses WHERE buses.id=
    busId) = TRUE THEN RETURN true; ELSE RETURN FALSE ;
    END IF ;
END;
$$;
